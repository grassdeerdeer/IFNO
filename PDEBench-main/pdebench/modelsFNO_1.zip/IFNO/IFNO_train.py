# coding:UTF-8
# @Time: 2022/11/13 17:52
# @Author: Lulu Cao
# @File: IFNO_train.py
# @Software: PyCharm


import deepxde as dde
import numpy as np
import pickle
import matplotlib.pyplot as plt
import os, sys
import torch

import sys
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import pickle
from timeit import default_timer
from torch.nn.parallel import DataParallel

sys.path.append(".")

device_ids = [0,1,2,3]
device = torch.device("cuda:{}".format(device_ids[0]) if torch.cuda.is_available() else 'cpu')


from .IFNO_utils  import IFNODatasetSingle,IFNODatasetMult
from .IFNO import IFNO1d,IFNO2d,IFNO3d
from metrics import *


def adjust_learning_rate(optimizer, learning_rate, scheduler_gamma):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    lr = learning_rate * scheduler_gamma
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    return lr



def run_training(if_training,continue_training,
                 epochs,learning_rate,scheduler_step,scheduler_gamma,batch_size,
                 flnm,single_file,
                 base_path='../data_download/data/1D/Advection/Train/'):
    print(f'Epochs = {epochs}, learning rate = {learning_rate}, scheduler step = {scheduler_step}, scheduler gamma = {scheduler_gamma}')
    print("device",device)
    ################################################################
    # load data
    ################################################################
    if single_file:
        # filename
        model_name = flnm[:-5] + '_IFNO'
        print("IFNODatasetSingle")

        # Initialize the dataset and dataloader
        train_data = IFNODatasetSingle(flnm,saved_folder=base_path,
                 reduced_resolution=1,reduced_resolution_t=1,reduced_batch=1,
                 if_test=False,test_ratio=0.1,num_samples_max=-1,
                 initial_step=10)
        val_data = IFNODatasetSingle(flnm,saved_folder=base_path,
                 reduced_resolution=1,reduced_resolution_t=1,reduced_batch=1,
                 if_test=True,test_ratio=0.1,num_samples_max=-1,
                 initial_step=10)
    else:
        # filename
        model_name = flnm + '_IFNO'

        train_data = IFNODatasetMult(flnm,
                 initial_step=10,
                 saved_folder=base_path,
                 if_test=False, test_ratio=0.1)
        val_data = IFNODatasetMult(flnm,
                 initial_step=10,
                 saved_folder=base_path,
                 if_test=True, test_ratio=0.1)
    batch_size = 80
    train_loader = torch.utils.data.DataLoader(train_data,num_workers=4, batch_size=batch_size,shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_data,num_workers=4, batch_size=batch_size,shuffle=False)

    ################################################################
    # training and evaluation
    ################################################################
    _data, _param, _ = next(iter(val_loader))
    dimensions = len(train_data.data_shape)-2
    print('Spatial Dimension', dimensions)

    if dimensions == 1:
        model = IFNO1d(_param.shape[1],_data.shape[-1],_param.shape[2:]).to(device)
        #model = IFNO1d(train_data.input_size,train_data.hiddensize,batch_size,train_data.num_layers).to(device)
    elif dimensions == 2:
        model = IFNO2d().to(device)
    elif dimensions == 3:
        model = IFNO3d().to(device)

    model = DataParallel(model, device_ids=device_ids, output_device=device)  # 将最后的结果gather到一个服务器上
    model_path = model_name + ".3pt"
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'Total parameters = {total_params}')

    ###### 构造损失函数和优化器 #####
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-4)  # 告诉优化器对哪些Tensor做梯度优化
    # scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=scheduler_step,
    #                                             gamma=scheduler_gamma)  # 每多少轮循环后更新一次学习率,每次更新lr的gamma倍
    loss_fn = torch.nn.MSELoss(reduction="mean") #在batch和特征维度上都做了平均

    start_epoch = 0
    ###### 测试 #####
    if not if_training:
        checkpoint = torch.load(model_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        model.to(device)
        model.eval()
        plot=True
        channel_plot=0
        x_min,x_max,y_min,y_max,t_min,t_max = 0,1,0,1,0,1
        Lx, Ly, Lz = 1., 1., 1.
        errs = metrics(val_loader, model, Lx, Ly, Lz, plot, channel_plot,
                       model_name, x_min, x_max, y_min, y_max,
                       t_min, t_max)
        pickle.dump(errs, open(model_name + '.pickle', "wb"))

        return




    if continue_training:
        print('Restoring model (that is the network\'s weights) from file...')
        checkpoint = torch.load(model_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        model.to(device)
        model.train()

        # Load optimizer state dict
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        for state in optimizer.state.values():
            for k, v in state.items():
                if isinstance(v, torch.Tensor):
                    state[k] = v.to(device)

        start_epoch = checkpoint['epoch']
        loss_val_min = checkpoint['loss']





    min_loss = 100
    cur_lr = learning_rate
    # for ep in range(start_epoch, epochs):
    #     model.train()
    #     t1 = default_timer()
    #     running_loss = 0
    #     optimizer.zero_grad()
    #     for coordinate, hidden, x_input, target in train_loader:
    #         hidden = torch.cat((hidden, coordinate), dim=1).to(device)  # ch 维度合并
    #         x_input = x_input.to(device)
    #         target = target.to(device)
    #
    #         # shape: B*S-》S*B
    #         # permute from [batch,ch,x] -> [ch,batch,x]
    #         permute_idx = [1, 0] + list(range(2, len(hidden.shape)))
    #         hidden = hidden.permute(permute_idx).contiguous()  # ch(numlayers),batch,x
    #         x_input = x_input.permute(permute_idx).contiguous()  # t(seqSize),batch,1
    #
    #         pred = torch.zeros(target.shape[:], device=hidden.device, dtype=torch.float)
    #         loss = 0
    #         for idx, inputs in enumerate(x_input):
    #             if idx == 0:
    #                 pred[:, idx, ...]=hidden[0]
    #             else:
    #                 out,hidden = model(hidden,inputs)
    #                 pred[:,idx,...]=out
    #                 loss += loss_fn(out, target[:,idx,...])
    #
    #
    #         #print(pred.shape,target.shape)
    #         loss = loss_fn(pred.reshape(target.shape[0], -1), target.reshape(target.shape[0], -1))
    #         optimizer.zero_grad()
    #         loss.backward()
    #         optimizer.step()
    #
    #         running_loss += loss.item()
    #
    #     t2 = default_timer()
    #     print(t2 - t1)
    #     running_loss = running_loss / len(train_loader)
    #     if min_loss > running_loss:
    #         torch.save({
    #             'epoch': ep,
    #             'model_state_dict': model.state_dict(),
    #             'optimizer_state_dict': optimizer.state_dict(),
    #             'loss': running_loss
    #         }, model_path)
    #         min_loss = running_loss
    #     elif min_loss < running_loss:
    #         cur_lr = adjust_learning_rate(optimizer, cur_lr, scheduler_gamma)
    #     # scheduler.step()
    #     print(f"epoch{ep},loss{running_loss}")


    ###### 训练 #####
    for ep in range(start_epoch, epochs):
        model.train()
        t1 = default_timer()
        running_loss = 0
        for data_input, param, data_output in train_loader:
            data_input = data_input.to(device)
            param = param.to(device)
            data_output = data_output.to(device)

            optimizer.zero_grad()

            outputs = model(param, data_input)
            loss = loss_fn(outputs, data_output.reshape(outputs.shape[0], -1))

            running_loss += loss.item()
            loss.backward()
            optimizer.step()

        t2 = default_timer()
        print(t2-t1)
        running_loss = running_loss/len(train_loader)
        if min_loss>running_loss:
            torch.save({
                'epoch': ep,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': running_loss
            }, model_path)
            min_loss = running_loss
        elif min_loss<running_loss:
            cur_lr = adjust_learning_rate(optimizer, cur_lr, scheduler_gamma)
        # scheduler.step()
        print(f"epoch{ep},loss{running_loss}")

if __name__ == "__main__":
    run_training()