# coding:UTF-8
# @Time: 2022/11/11 9:14
# @Author: Lulu Cao
# @File: getDataset.py
# @Software: PyCharm


import torch
from torch.utils.data import Dataset, IterableDataset
from torch.utils.data import DataLoader
import os
import glob
import h5py
import numpy as np
import math as mt

class IFNODatasetSingle(Dataset):
    def __init__(self,filename,saved_folder='../data/',
                 reduced_resolution=1,reduced_resolution_t=1,reduced_batch=1,
                 if_test=False,test_ratio=0.1,num_samples_max=-1,
                 initial_step=1,val_batch_idx=-1):
        # Define path to files
        root_path = os.path.abspath(saved_folder + filename)
        assert filename[-2:] != 'h5', 'HDF5 data is assumed!!'

        with h5py.File(root_path, 'r') as f:
            self.keys = list(f.keys())
            self.keys.sort()
            if 'tensor' not in self.keys:
                _data = np.array(f['density'], dtype=np.float32)  # batch, time, x,...
                idx_cfd = _data.shape
                if len(idx_cfd) == 3:  # 1D
                    self.data = np.zeros([idx_cfd[0] // reduced_batch,
                                          idx_cfd[2] // reduced_resolution,
                                          mt.ceil(idx_cfd[1] / reduced_resolution_t),
                                          3],
                                         dtype=np.float32)
                    # density
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data[:, :, :], (0, 2, 1))
                    self.data[..., 0] = _data  # batch, x, t, ch
                    # pressure
                    _data = np.array(f['pressure'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data[:, :, :], (0, 2, 1))
                    self.data[..., 1] = _data  # batch, x, t, ch
                    # Vx
                    _data = np.array(f['Vx'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data[:, :, :], (0, 2, 1))
                    self.data[..., 2] = _data  # batch, x, t, ch

                    self.grid = np.array(f["x-coordinate"], dtype=np.float32)
                    self.grid = torch.tensor(self.grid[::reduced_resolution], dtype=torch.float).unsqueeze(-1)
                    print(self.data.shape)
                if len(idx_cfd) == 4:  # 2D
                    self.data = np.zeros([idx_cfd[0] // reduced_batch,
                                          idx_cfd[2] // reduced_resolution,
                                          idx_cfd[3] // reduced_resolution,
                                          mt.ceil(idx_cfd[1] / reduced_resolution_t),
                                          4],
                                         dtype=np.float32)
                    # density
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 1))
                    self.data[..., 0] = _data  # batch, x, t, ch
                    # pressure
                    _data = np.array(f['pressure'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 1))
                    self.data[..., 1] = _data  # batch, x, t, ch
                    # Vx
                    _data = np.array(f['Vx'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 1))
                    self.data[..., 2] = _data  # batch, x, t, ch
                    # Vy
                    _data = np.array(f['Vy'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 1))
                    self.data[..., 3] = _data  # batch, x, t, ch

                    x = np.array(f["x-coordinate"], dtype=np.float32)
                    y = np.array(f["y-coordinate"], dtype=np.float32)
                    x = torch.tensor(x, dtype=torch.float)
                    y = torch.tensor(y, dtype=torch.float)
                    X, Y = torch.meshgrid(x, y)
                    self.grid = torch.stack((X, Y), axis=-1)[::reduced_resolution, ::reduced_resolution]

                if len(idx_cfd) == 5:  # 3D
                    self.data = np.zeros([idx_cfd[0] // reduced_batch,
                                          idx_cfd[2] // reduced_resolution,
                                          idx_cfd[3] // reduced_resolution,
                                          idx_cfd[4] // reduced_resolution,
                                          mt.ceil(idx_cfd[1] / reduced_resolution_t),
                                          5],
                                         dtype=np.float32)
                    # density
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution,
                            ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 4, 1))
                    self.data[..., 0] = _data  # batch, x, t, ch
                    # pressure
                    _data = np.array(f['pressure'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution,
                            ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 4, 1))
                    self.data[..., 1] = _data  # batch, x, t, ch
                    # Vx
                    _data = np.array(f['Vx'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution,
                            ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 4, 1))
                    self.data[..., 2] = _data  # batch, x, t, ch
                    # Vy
                    _data = np.array(f['Vy'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution,
                            ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 4, 1))
                    self.data[..., 3] = _data  # batch, x, t, ch
                    # Vz
                    _data = np.array(f['Vz'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution, ::reduced_resolution,
                            ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data, (0, 2, 3, 4, 1))
                    self.data[..., 4] = _data  # batch, x, t, ch

                    x = np.array(f["x-coordinate"], dtype=np.float32)
                    y = np.array(f["y-coordinate"], dtype=np.float32)
                    z = np.array(f["z-coordinate"], dtype=np.float32)
                    x = torch.tensor(x, dtype=torch.float)
                    y = torch.tensor(y, dtype=torch.float)
                    z = torch.tensor(z, dtype=torch.float)
                    X, Y, Z = torch.meshgrid(x, y, z)
                    self.grid = torch.stack((X, Y, Z), axis=-1)[::reduced_resolution, \
                                ::reduced_resolution, \
                                ::reduced_resolution]

            else:  # scalar equations
                #self._data = torch.tensor(f['tensor'], dtype=torch.float)
                _data = np.array(f['tensor'], dtype=np.float32)  # batch, time, x,...
                if len(_data.shape) == 3:  # 1D
                    self.data_shape = _data.shape
                    _data = _data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution]

                    # # output
                    # self.output = torch.tensor(_data, dtype=torch.float)
                    #
                    #
                    # ## convert to [batch,x1, ..., xd, t]
                    # _data = np.transpose(_data[:, :, :], (0, 2, 1))
                    # init_data = _data[..., 0,]
                    # init_data = init_data[:,None,...] # batch,1,xn
                    # self.hidden = init_data # batch,1,xn
                    #
                    # # 综合坐标
                    # self.data_grid_x = torch.tensor(f["x-coordinate"][::reduced_resolution], dtype=torch.float)
                    # self.data_grid_x = self.data_grid_x[None,...] # ch,xn
                    # self.coordinate = torch.tensor(self.data_grid_x,dtype=torch.float)
                    # # self.hidden = np.concatenate([self.hidden, self.data_grid_x], axis=1) # batch,ch,xn
                    #
                    # # input/t
                    # self.data_grid_t = torch.tensor(f["t-coordinate"][::reduced_resolution_t], dtype=torch.float)
                    # self.tdim = _data.shape[-1]
                    # self.data_grid_t = self.data_grid_t[:self.tdim,None]
                    # self.data_grid_t[1:] = torch.diff(self.data_grid_t,dim=0)
                    # self.x_input = self.data_grid_t  # batch,t,1(inputsize)
                    #
                    # self.input_size = 1
                    # self.hiddensize = self.hidden.shape[2]
                    # self.num_layers = self.hidden.shape[1]+self.coordinate.shape[0]


                    ## convert to [x1, ..., xd, t]
                    _data = np.transpose(_data[:, :, :], (0, 2, 1))
                    self.data = _data[:, :, :, None]  # batch, x, t, ch
                    init_data = np.repeat(_data[...,0,None,None],_data.shape[-1],axis=-2)
                    # init_data = np.transpose(init_data[:, :, :], (1, 2, 0))
                    # init_data = init_data[:,:,:,None]
                    self.data = np.concatenate([init_data,self.data], axis=-1)
                    self.data = np.transpose(self.data[:,:,:,:],(0,3,1,2))

                    #
                    # self._data = self._data[::reduced_batch, ::reduced_resolution_t, ::reduced_resolution]
                    # self.get_index_sample(val_batch_idx)  # 获得self.data_output
                    #
                    self.data_grid_x = torch.tensor(f["x-coordinate"][::reduced_resolution], dtype=torch.float)
                    # self.dx = self.data_grid_x[1] - self.data_grid_x[0]
                    # self.xL = self.data_grid_x[0] - 0.5 * self.dx
                    # self.xR = self.data_grid_x[-1] + 0.5 * self.dx
                    # self.xdim = self.data_grid_x.size(0)
                    #
                    self.data_grid_t = torch.tensor(f["t-coordinate"][::reduced_resolution_t], dtype=torch.float)
                    #
                    self.tdim = self.data.shape[-1]
                    self.data_grid_t = self.data_grid_t[:self.tdim]
                    #
                    XX, TT = torch.meshgrid(
                        [self.data_grid_x, self.data_grid_t]
                    )
                    # self.list_t = list(self.data_grid_t)
                    # self.list_x = list(self.data_grid_x)
                    #
                    self.data_input = torch.vstack([XX.ravel(), TT.ravel()]).T



                if len(_data.shape) == 4:  # 2D Darcy flow
                    # u: label
                    self._data = self._data[::reduced_batch, :, ::reduced_resolution, ::reduced_resolution]
                    self.get_index_sample(self, val_batch_idx)  # 获得self.data_output

                    ## convert to [x1, ..., xd, t, v]
                    self._data = np.transpose(self._data[:, :, :, :], (0, 2, 3, 1))
                    # if _data.shape[-1]==1:  # if nt==1
                    #    _data = np.tile(_data, (1, 1, 1, 2))

                    # nu: input
                    _data = np.array(f['nu'], dtype=np.float32)  # batch, time, x,...
                    _data = _data[::reduced_batch, None, ::reduced_resolution, ::reduced_resolution]
                    ## convert to [x1, ..., xd, t, v]
                    _data = np.transpose(_data[:, :, :, :], (0, 2, 3, 1))
                    self.data = np.concatenate([self.data,_data], axis=-1)
                    self.get_index_sample(self, val_batch_idx)

                    self.data_grid_x = torch.tensor(f["x-coordinate"][::reduced_resolution], dtype=torch.float)
                    self.data_grid_y = torch.tensor(f["y-coordinate"][::reduced_resolution], dtype=torch.float)
                    #self.dx = self.data_grid_x[1] - self.data_grid_x[0]
                    #self.xL = self.data_grid_x[0] - 0.5 * self.dx
                    #self.xR = self.data_grid_x[-1] + 0.5 * self.dx
                    #self.xdim = self.data_grid_x.size(0)

                    XX, YY = torch.meshgrid(
                        [self.data_grid_x, self.data_grid_y]
                    )
                    self.list_x = list(self.data_grid_x)
                    self.list_y = list(self.data_grid_y)

                    self.data_input = torch.vstack([XX.ravel(), YY.ravel()]).T

        if num_samples_max>0:
            num_samples_max  = min(num_samples_max,self.data.shape[0])
        else:
            num_samples_max = self.data.shape[0]

        test_idx = int(num_samples_max * test_ratio)
        if if_test:
            # self.hidden = self.hidden[:test_idx]
            # self.output = self.output[:test_idx]
            self.data = self.data[:test_idx]
        else:
            # self.hidden = self.hidden[test_idx:num_samples_max]
            # self.output = self.output[test_idx:num_samples_max]
            self.data = self.data[test_idx:num_samples_max]



    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # [x1, ..., xd, t, v]
        return self.data_input, self.data[idx,:1,...], self.data[idx,1:,...]
        #return self.coordinate, self.hidden[idx,...,], self.x_input, self.output[idx]





    # def get_index_sample(self,index):
    #     if 'tensor' not in self.keys:
    #         pass
    #     else:
    #         if len(self._data.shape) == 3:
    #             self.data_output = self._data[index]
    #             # permute from [t, x] -> [x, t]
    #             self.data_output = self.data_output.T
    #
    #             # for init/boundary conditions
    #             self.init_data = self.data_output[..., 0]
    #             self.bd_data_L = self.data_output[0]
    #             self.bd_data_R = self.data_output[-1]
    #             self.data_output = self.data_output.reshape(-1, 1)
    #         if len(self._data.shape) == 4:  # 2D Darcy flow
    #             self.data_output = self._data[index,...,0]
    #
    #             # for init/boundary conditions
    #             self.init_data = self._data[index,...,1] #这里其实不算initial data，而是param a(x)
    #             # self.bd_data_L = self.data_output[0]
    #             # self.bd_data_R = self.data_output[-1]
    #             self.data_output = self.data_output.reshape(-1, 1)
    #
    #
    #
    # def __len__(self):
    #     return self._data.shape[0]
    #
    # def __getitem__(self, idx):
    #     if 'tensor' not in self.keys:
    #         pass
    #     else:
    #         if len(self._data.shape) == 3:#1D
    #             tt = self.data_input[idx][-1]
    #             space = self.data_input[idx][:-1]
    #
    #             tempindexx = self.list_x.index(space[0])
    #             tempindext = self.list_t.index(tt)
    #             self.param = torch.vstack(
    #                 [self.init_data[tempindexx], self.bd_data_L[tempindext], self.bd_data_R[tempindext]])
    #             return self.data_input[idx], self.param.view((-1)), self.data_output[idx]
    #         if len(self._data.shape) == 4:
    #             space = self.data_input[idx][:]
    #             tempindexx = self.list_x.index(space[0])
    #             tempindexy = self.list_y.index(space[1])
    #             self.param = torch.vstack(
    #                 [self.init_data[tempindexx][tempindexy],0])  #u(x)=0边界条件
    #             return self.data_input[idx], self.param.view((-1)), self.data_output[idx]
    #


class IFNODatasetMult(Dataset):
    def __init__(self, filename,
                 initial_step=10,
                 saved_folder='../data_download/data/2D/diffusion-reaction/',
                 if_test=False, test_ratio=0.1):
        # Define path to files
        self.file_path = os.path.abspath(saved_folder + filename + ".h5")
        # Extract list of seeds
        with h5py.File(self.file_path, 'r') as h5_file:
            data_list = sorted(h5_file.keys())
        test_idx = int(len(data_list) * (1 - test_ratio))
        if if_test:
            self.data_list = np.array(data_list[test_idx:])
        else:
            self.data_list = np.array(data_list[:test_idx])

        # Time steps used as initial conditions
        self.initial_step = initial_step

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):

        # Open file and read data
        with h5py.File(self.file_path, 'r') as h5_file:
            seed_group = h5_file[self.data_list[idx]]

            # data dim = [t, x1, ..., xd, v]
            data = np.array(seed_group["data"], dtype='f')
            data = torch.tensor(data, dtype=torch.float)

            # convert to [x1, ..., xd, t, v]
            permute_idx = list(range(1, len(data.shape) - 1))
            permute_idx.extend(list([0, -1]))  # 在原来的list后追加[0,-1]
            data = data.permute(permute_idx)

            # Extract spatial dimension of data
            dim = len(data.shape) - 2

            # x, y and z are 1-D arrays
            # Convert the spatial coordinates to meshgrid
            if dim == 1:
                grid = np.array(seed_group["grid"]["x"], dtype='f')
                grid = torch.tensor(grid, dtype=torch.float).unsqueeze(-1)
            elif dim == 2:
                x = np.array(seed_group["grid"]["x"], dtype='f')
                y = np.array(seed_group["grid"]["y"], dtype='f')
                x = torch.tensor(x, dtype=torch.float)
                y = torch.tensor(y, dtype=torch.float)
                X, Y = torch.meshgrid(x, y)
                grid = torch.stack((X, Y), axis=-1)
            elif dim == 3:
                x = np.array(seed_group["grid"]["x"], dtype='f')
                y = np.array(seed_group["grid"]["y"], dtype='f')
                z = np.array(seed_group["grid"]["z"], dtype='f')
                x = torch.tensor(x, dtype=torch.float)
                y = torch.tensor(y, dtype=torch.float)
                z = torch.tensor(z, dtype=torch.float)
                X, Y, Z = torch.meshgrid(x, y, z)
                grid = torch.stack((X, Y, Z), axis=-1)

        return data[..., :self.initial_step, :], data, grid





if __name__=="__main__":
    filename = "1D_Advection_Sols_beta0.1.hdf5"
    root_path = "../../data_download/data/1D/Advection/Train/"
